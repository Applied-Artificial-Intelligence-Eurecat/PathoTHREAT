import pandas as pd
import sys
import json
import datetime

import requests


def csv_str_to_json(csv: str) -> list[dict]:
    return pd.read_csv(csv, sep=';').to_json(orient='records')

def from_dict_to_document(a: dict) -> dict:
    return {
        'name': a['Title'],
        'data': datetime.datetime.now().isoformat(),
        'source': a['Title'],
        'url': a['Title'],
        'keywords': a['Title'],
        'text': f"""Detection
{a['Detection']}

Cause:
{a['Cause']}

Source:
{a['Source']}

Mitigation:
{a['Mitigation']}

Location
City: {a['Location-City']}
Region: {a['Location-Region']}
Country: {a['Location-Country']}

Impact
Dead: {a['Impact-Dead']}
Hospitalized: {a['Impact-Hospitalized']}

Monitoring
{a['Monitoring']}

Contaminant
{a['Contaminant']}

Syntomps
{a['Symptoms']}

Prevention
{a['Prevention']}

Restoration
{a['Restoration']}
""",
    }

if __name__ == '__main__':
    v = json.loads(csv_str_to_json(sys.argv[1]))
    print(type(v))
    
    token = "somethingsomething"
    a = requests.post("http://localhost:4567/api/authenticate", data=json.dumps({
        "username": "admin",
        "password": "root"
    }), headers={
        "Accept": "application/hal+json",
        "Content-Type": "application/json",
    })
    token = a.json()["token"]
    transformed = map(from_dict_to_document, v)
    for j in transformed:
        a = requests.post("http://localhost:4567/api/documents", data=json.dumps(j), headers={
            "Accept": "application/hal+json",
            "Authorization": f"Bearer {token}"
        })
        print(json.loads(a.content))